
class Effect_RowCol {
private:  
  byte pulsePos;
  void fastLine(int x1, int y1, int x2, int y2);
  
public:
 Effect_RowCol();
 void Tick();
 void buttonChange(byte x, byte y, byte state);
};

